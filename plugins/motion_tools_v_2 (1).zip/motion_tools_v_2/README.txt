Online documentation with history of changes:
https://zimoby.notion.site/Motion-Tools-Classic-1dfe50bd46e78099ab58d3333f02b984?pvs=4

INSTALLATION

(1) copy the file "Motion Tools.jsxbin" into the folder
"Support Files/Scripts/ScriptUI Panels" (on Windows) or
"Scripts/ScriptUI Panels" (on Mac) of your After Effects
installation. 

(2) Start "Motion Tools.jsxbin" (via the "Window" menu in After Effects)

ABOUT

Motion Tools is a universal script with tools allowing to do boring things fast.